package com.pubsfs.sfseditor;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CompoundButton;
import android.widget.AdapterView;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class BpSelectActivity extends Activity {
	
	
	private double pathToNameMapTransNumVariable = 0;
	private double variableForSearchMapTransfer = 0;
	
	private ArrayList<String> bpDirPaths = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> bpNames = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> searchFilteredNames = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private CheckBox checkbox1;
	private ListView listview1;
	private Button button1;
	private EditText edittext1;
	
	private Intent intent = new Intent();
	private SharedPreferences preferences;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.bp_select);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		checkbox1 = findViewById(R.id.checkbox1);
		listview1 = findViewById(R.id.listview1);
		button1 = findViewById(R.id.button1);
		edittext1 = findViewById(R.id.edittext1);
		preferences = getSharedPreferences("shared", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				variableForSearchMapTransfer = 0;
				searchFilteredNames.clear();
				if (edittext1.getText().toString().length() > 0) {
					for(int _repeat16 = 0; _repeat16 < (int)(bpNames.size()); _repeat16++) {
						if (_isChecked) {
							if (Uri.parse(bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString()).getLastPathSegment().contains(edittext1.getText().toString())) {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("BPName", bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString());
									searchFilteredNames.add(_item);
								}
								
							}
						}
						else {
							if (Uri.parse(bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString()).getLastPathSegment().toLowerCase().contains(edittext1.getText().toString().toLowerCase())) {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("BPName", bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString());
									searchFilteredNames.add(_item);
								}
								
							}
						}
						variableForSearchMapTransfer++;
					}
					listview1.setAdapter(new Listview1Adapter(searchFilteredNames));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
				else {
					listview1.setAdapter(new Listview1Adapter(bpNames));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (edittext1.getText().toString().length() > 0) {
					preferences.edit().putString("Path", searchFilteredNames.get((int)_position).get("BPName").toString()).commit();
				}
				else {
					preferences.edit().putString("Path", bpNames.get((int)_position).get("BPName").toString()).commit();
				}
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/Android/data/com.StefMorojna.SpaceflightSimulator/files/Saving/Blueprints/"), bpDirPaths);
				pathToNameMapTransNumVariable = 0;
				bpNames.clear();
				for(int _repeat15 = 0; _repeat15 < (int)(bpDirPaths.size()); _repeat15++) {
					if (FileUtil.isDirectory(bpDirPaths.get((int)(pathToNameMapTransNumVariable)))) {
						{
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("BPName", bpDirPaths.get((int)(pathToNameMapTransNumVariable)));
							bpNames.add(_item);
						}
						
					}
					pathToNameMapTransNumVariable++;
				}
				listview1.setAdapter(new Listview1Adapter(bpNames));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				variableForSearchMapTransfer = 0;
				searchFilteredNames.clear();
				if (_charSeq.length() > 0) {
					for(int _repeat53 = 0; _repeat53 < (int)(bpNames.size()); _repeat53++) {
						if (checkbox1.isChecked()) {
							if (Uri.parse(bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString()).getLastPathSegment().contains(_charSeq)) {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("BPName", bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString());
									searchFilteredNames.add(_item);
								}
								
							}
						}
						else {
							if (Uri.parse(bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString()).getLastPathSegment().toLowerCase().contains(_charSeq.toLowerCase())) {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("BPName", bpNames.get((int)variableForSearchMapTransfer).get("BPName").toString());
									searchFilteredNames.add(_item);
								}
								
							}
						}
						variableForSearchMapTransfer++;
					}
					listview1.setAdapter(new Listview1Adapter(searchFilteredNames));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
				else {
					listview1.setAdapter(new Listview1Adapter(bpNames));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		if (!preferences.contains("tutorial2")) {
			preferences.edit().putString("tutorial2", "True").commit();
		}
		if (preferences.getString("tutorial2", "").equals("True")) {
			dialog.setTitle("TIPS");
			dialog.setMessage("-use 'match cases' to find more specific blueprints\n-if a newly added bp is missing, try clicking the 'REFRESH' button");
			dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial2", "True").commit();
				}
			});
			dialog.setNegativeButton("never show again", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial2", "False").commit();
				}
			});
			dialog.create().show();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/Android/data/com.StefMorojna.SpaceflightSimulator/files/Saving/Blueprints/"), bpDirPaths);
		pathToNameMapTransNumVariable = 0;
		bpNames.clear();
		for(int _repeat15 = 0; _repeat15 < (int)(bpDirPaths.size()); _repeat15++) {
			if (FileUtil.isDirectory(bpDirPaths.get((int)(pathToNameMapTransNumVariable)))) {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("BPName", bpDirPaths.get((int)(pathToNameMapTransNumVariable)));
					bpNames.add(_item);
				}
				
			}
			pathToNameMapTransNumVariable++;
		}
		listview1.setAdapter(new Listview1Adapter(bpNames));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.bp_list_custom_view, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			textview1.setText(Uri.parse(_data.get((int)_position).get("BPName").toString()).getLastPathSegment());
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}