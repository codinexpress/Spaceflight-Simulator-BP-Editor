package com.pubsfs.sfseditor;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.CompoundButton;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class EditorActivity extends Activity {
	
	
	private LinearLayout main;
	private LinearLayout linear2;
	private HorizontalScrollView hscroll1;
	private ScrollView vscroll1;
	private Switch editablePath;
	private CheckBox checkbox1;
	private Button openBPButton;
	private Button cancelButton;
	private Button saveButton;
	private EditText bpFilePath;
	private EditText bpFileContent;
	
	private Intent intent = new Intent();
	private SharedPreferences preferences;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.editor);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = findViewById(R.id.main);
		linear2 = findViewById(R.id.linear2);
		hscroll1 = findViewById(R.id.hscroll1);
		vscroll1 = findViewById(R.id.vscroll1);
		editablePath = findViewById(R.id.editablePath);
		checkbox1 = findViewById(R.id.checkbox1);
		openBPButton = findViewById(R.id.openBPButton);
		cancelButton = findViewById(R.id.cancelButton);
		saveButton = findViewById(R.id.saveButton);
		bpFilePath = findViewById(R.id.bpFilePath);
		bpFileContent = findViewById(R.id.bpFileContent);
		preferences = getSharedPreferences("shared", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		editablePath.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				bpFilePath.setEnabled(_isChecked);
				if (!_isChecked) {
					if (preferences.contains("Path")) {
						bpFilePath.setText(preferences.getString("Path", "").concat("/Blueprint.txt"));
					}
				}
			}
		});
		
		openBPButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), BpSelectActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		cancelButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bpFilePath.setText("");
				bpFileContent.setText("");
				preferences.edit().remove("Path").commit();
			}
		});
		
		saveButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile(bpFilePath.getText().toString(), bpFileContent.getText().toString());
				if (editablePath.isChecked()) {
					SketchwareUtil.showMessage(getApplicationContext(), "saved to ".concat(bpFilePath.getText().toString()));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "saved");
				}
				if (!checkbox1.isChecked()) {
					bpFilePath.setText("");
					bpFileContent.setText("");
					preferences.edit().remove("Path").commit();
				}
			}
		});
		
		bpFilePath.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				
				return true;
				}
			 });
		
		bpFileContent.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.length() > 0) {
					cancelButton.setVisibility(View.VISIBLE);
					saveButton.setVisibility(View.VISIBLE);
					openBPButton.setVisibility(View.GONE);
				}
				else {
					cancelButton.setVisibility(View.GONE);
					saveButton.setVisibility(View.GONE);
					openBPButton.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		cancelButton.setVisibility(View.GONE);
		saveButton.setVisibility(View.GONE);
		if (preferences.contains("Path")) {
			bpFilePath.setText(preferences.getString("Path", "").concat("/Blueprint.txt"));
			bpFileContent.setText(FileUtil.readFile(preferences.getString("Path", "").concat("/Blueprint.txt")));
		}
		if (preferences.contains("editorTheme")) {
			if (preferences.getString("editorTheme", "").equals("0")) {
				main.setBackgroundColor(Color.TRANSPARENT);
				bpFilePath.setTextColor(0xFF000000);
				bpFileContent.setTextColor(0xFF000000);
			}
			else {
				if (preferences.getString("editorTheme", "").equals("1")) {
					main.setBackgroundColor(0xFF000000);
					bpFilePath.setTextColor(0xFFFFFFFF);
					bpFileContent.setTextColor(0xFFFFFFFF);
				}
				else {
					main.setBackgroundColor(0xFF000000);
					bpFilePath.setTextColor(0xFF00C853);
					bpFileContent.setTextColor(0xFF00C853);
				}
			}
		}
		if (!preferences.contains("tutorial1")) {
			preferences.edit().putString("tutorial1", "True").commit();
		}
		if (preferences.getString("tutorial1", "").equals("True")) {
			dialog.setTitle("Tutorial");
			dialog.setMessage("How to start editing?\n\ntap 'open bp' and select the bp you want to edit, or you can search it up using the search bar,\nyou can enable the 'match cases' to find the exact cases of the blueprint's name, once a bp is selected you can now start editing, once done, tap save to save your edit, or cancel to clear the editor.\n\nnote that the editor will automatically close after saving if 'continuous' is not enabled\n\nfor advance users:\nyou can enable 'edit path' to edit the path to where the bp should be saved\nnote that if you turn off the 'edit path' it'll reset the path to the bp's default path");
			dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial1", "True").commit();
				}
			});
			dialog.setNegativeButton("never show again", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial1", "False").commit();
				}
			});
			dialog.create().show();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (preferences.contains("Path")) {
			bpFilePath.setText(preferences.getString("Path", "").concat("/Blueprint.txt"));
			bpFileContent.setText(FileUtil.readFile(preferences.getString("Path", "").concat("/Blueprint.txt")));
		}
	}
	public boolean _str(final String _bool) {
		if (_bool.equals("True")) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}