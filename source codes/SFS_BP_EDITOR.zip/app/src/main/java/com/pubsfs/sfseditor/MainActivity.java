package com.pubsfs.sfseditor;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double backpressvariable = 0;
	
	private LinearLayout main;
	private TextView textview1;
	private TextView textview2;
	private Button launchEditorButton;
	private Button launchSFSButton;
	private Button settingsButton;
	private Button aboutButton;
	private Button exitButton;
	
	private Intent intent = new Intent();
	private TimerTask delay;
	private SharedPreferences preferences;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = findViewById(R.id.main);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		launchEditorButton = findViewById(R.id.launchEditorButton);
		launchSFSButton = findViewById(R.id.launchSFSButton);
		settingsButton = findViewById(R.id.settingsButton);
		aboutButton = findViewById(R.id.aboutButton);
		exitButton = findViewById(R.id.exitButton);
		preferences = getSharedPreferences("shared", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		launchEditorButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), EditorActivity.class);
				startActivity(intent);
			}
		});
		
		launchSFSButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent = getPackageManager().getLaunchIntentForPackage("com.StefMorojna.SpaceflightSimulator");
				startActivity(intent);
			}
		});
		
		settingsButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(intent);
			}
		});
		
		aboutButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(intent);
			}
		});
		
		exitButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finishAffinity();
			}
		});
	}
	
	private void initializeLogic() {
		if (!preferences.contains("tutorial")) {
			preferences.edit().putString("tutorial", "True").commit();
		}
		if (preferences.getString("tutorial", "").equals("True")) {
			dialog.setTitle("Tutorial");
			dialog.setMessage("what do these buttons do?\n\nEDITOR - opens the bp editor\nLAUNCH SFS - opens the spaceflight simulator game\nSETTINGS - opens settings\nABOUT - about SFS BP EDITOR and its developers and contributors\nEXIT - exit the app\n\ntry finding the easter egg\n😁");
			dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial", "True").commit();
				}
			});
			dialog.setNegativeButton("never show again", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					preferences.edit().putString("tutorial", "False").commit();
				}
			});
			dialog.create().show();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}